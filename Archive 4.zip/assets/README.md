Please place the Cremma store image here with the filename: `cremma-store.jpg`

The image should be high resolution and show the storefront of Cremma, similar to the one shown in the login page design.
